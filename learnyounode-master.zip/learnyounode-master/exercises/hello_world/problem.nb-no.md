Skriv et program som skriver ut teskten "Hei verden" til skjermen (stdout).

----------------------------------------------------------------------
## HINT

For å lage et Node.js program må du lage en ny fil med `.js` som filtype. Deretter er det bare å skrive JavaScript! Kjør programmet ditt med å kjøre `node` kommandoen. f.eks:

```sh
$ node program.js
```

Du kan skrive til skjermen på samme måte som du skriver til consolet i en nettleser:

```js
console.log("tekst")
```

Når du er ferdig, må du kjøre:

```sh
$ {appname} verify program.js
```

for å fortsette. Programmet vil bli testet og det blir laget en rapport. Oppgaven blir markert som 'løst' hvis verifiseringen gikk bra.
