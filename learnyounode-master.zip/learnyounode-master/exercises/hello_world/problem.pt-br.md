Escreva um programa que imprime o texto "Olá, Mundo" no console (stdout).

----------------------------------------------------------------------
## Dicas

Para fazer um programa Node.js, crie um novo arquivo com a extensão `.js` e comece a escrever JavaScript! Execute seu programa rodando ele com o comando `node`. Por exemplo:

```sh
$ node program.js
```

Você pode escrever no console da mesma maneira que no navegador:

```js
console.log("texto")
```

Quando tiver terminado seu código, você deverá executar:

```sh
$ {appname} verify program.js
```

para proceder. Seu programa será testado, um relatório será gerado e a lição será marcada como 'completa' caso você tenha sucesso.
