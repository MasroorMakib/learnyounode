// Triggers: fail.mod.missing_error
require('./module_invalid_05')
