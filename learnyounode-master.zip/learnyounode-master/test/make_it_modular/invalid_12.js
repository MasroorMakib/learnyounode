// Triggers: fail.mod.callback_error
require('./module_invalid_11')(process.argv[2], process.argv[3], function () {})
