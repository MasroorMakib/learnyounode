// Triggers: fail.mod.callback_arguments
require('./module_invalid_06')
