var fs = require('fs')

fs.readFile(process.argv[2], countNewLines)

function countNewLines (_, text) {
  console.log(-1)
}
